<?php include 'header.php' ?>

<a href="add-category.php" class="btn btn-warning float-sm-right m-2 p-2">ADD CATEGORY</a>
<a href="index.php" class="btn btn-primary float-sm-right m-2 p-2">ADD DATA</a>

<br><br>

<div class="container">
            <form class="d-flex" role="search" action="search.php" method="POST">
                <input class="form-control me-2" type="search" name="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-info" name="searchbtn" type="submit">Search</button> 
            </form>
        </div>


<?php
 include 'config.php';
 if(isset($_GET['page'])){$_GET['page'];}else{$_GET['page']=1;}
 $limit=5;
 $offset=($_GET['page']-1)*$limit;
 $sql= "SELECT *FROM project LIMIT {$offset},{$limit} ";
 $runsql= mysqli_query($conn,$sql) or die(mysqli_errno($conn));
 if(mysqli_num_rows($runsql)>0){
echo '<table border="2" class="m-2" cellpadding="4px" cellspacing="2px" width="100%">
<thead>
<tr bgcolor="black" style="color:#fff;">
<th>#</th>
<th>NAME</th>
<th>GENDER</th>
<th>EMAIL</th>
<th>MESSAGE</th>
<th align="right" style="text-algin:right">OPERATION</th>
</tr>
</thead>
 <tbody>';
$Abc=1;
foreach($runsql as $value){
    
echo '<tr>
<td> '.$Abc++.'</td>
<td> '.$value["project_name"].' </td>
<td>'.$value["project_gender"].'</td>
<td>'.$value["project_email"].' </td>
<td>'.$value["project_message"].' </td>
<td> 
<a href="update.php?uid='.$value["project_id"].'" class="btn btn-success" >  EDIT</a>
<a href="show.php?sid='.$value["project_id"].'" class="btn btn-info">  SHOW</a>
<a href="delete.php?del_id='.$value["project_id"].'"class="btn btn-danger" > DEL</a>


</td>

</tr>';

 echo '</tbody>';
 }
 echo '</table>';
 
 }else{
    echo'ROW NOT FOUND';
 }


?>
<br>
<?php
echo '<nav aria-label="...">
<ul class="pagination pagination-lg">';
if($_GET['page']>1){
echo '<li class="page-item"><a class="page-link" href="display.php?page='.($_GET['page']-1).'">Pre</a></li>';}
   $sqlpage= "SELECT *FROM project"; $runpage=mysqli_query($conn,$sqlpage)or die(mysqli_errno($conn));
   $total_record=mysqli_num_rows($runpage);
   $total_page   = ceil($total_record/$limit);
   for($i=1; $i<=$total_page; $i++){
   if($i==$_GET['page']){$active="active";}else{ $active="";}
   echo '<li class="'.$active.'"><a class="page-link" href="display.php?page='.$i.'">'.$i.'</a></li>';}
if($total_page>$_GET['page']){  
echo '<li class="page-item"><a class="page-link" href="display.php?page='.($_GET['page']+1).'">Next</a></li>';}
echo '</ul></nav>';
?>
<?php  include 'footer.php'?>
