<?php 

include 'header.php';
include 'config.php';
$delsuccess=0;
if($_GET['del_id']){
    $sqldel= "DELETE FROM project WHERE project_id='".$_GET['del_id']."' ";
    $rundel= mysqli_query($conn,$sqldel) or die(mysqli_errno($conn));
    if($rundel){
      $delsuccess=1;
      ?>  <meta HTTP-EQUIV="Refresh" content="3; URL=display.php">
            <?php  
    }
}


if($delsuccess){
   echo '<div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
 <strong>DATA!</strong> Deleted Successfully!!!!!.
 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
';
}


include 'footer.php';

?>