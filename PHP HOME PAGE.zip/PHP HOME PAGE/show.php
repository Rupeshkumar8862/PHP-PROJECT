<?php 
include 'header.php';
include 'config.php';

if($_GET['sid']!=''){
 $showsql= "SELECT *FROM project WHERE project_id = '".$_GET['sid']."'";
 $runshow= mysqli_query($conn,$showsql) or die(mysqli_errno($conn));
 $singledata= mysqli_fetch_assoc($runshow);
//  echo '<pre>';
//  print_r($singledata);
//  echo '</pre>';
// echo $singledata['project_email'];

}





?>

<div class="container">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h1>Single Data</h1>
            </div>
            <div class="card-body">
                <p>
                    <b>NAME:</b> <?php echo $singledata['project_name'];?>
                </p>
                <p>
                    <b>EMAIL:</b> <?php echo $singledata['project_email'];?>
                </p>
                <p>
                    <b>GENDER:</b> <?php echo $singledata['project_gender'];?>
                </p>
                <p>
                    <b>MESSAGE</b> <?php echo $singledata['project_message'];?>
                </p>
            </div>
        </div>
    </div>
</div>

<?php  include 'footer.php' ?>