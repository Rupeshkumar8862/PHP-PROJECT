<?php include 'header.php' ;

include 'config.php';
$success=0;
if($_GET['uid']!=""){
$datafetbyid= "SELECT *FROM project where project_id='".$_GET['uid']."'";
$runsql= mysqli_query($conn,$datafetbyid) or die(mysqli_errno($conn));
$editdata= mysqli_fetch_assoc($runsql) ;
}
// echo '<pre>';
// print_r($editdata);
// echo '</pre>';
// acess particular values
// echo $editdata['project_id'].'<br>';
// echo $editdata['project_name'] .'<br>';
// echo $editdata['project_email'].'<br>';
// echo $editdata['project_gender'].'<br>';
// echo $editdata['project_message'].'<br>';
//  $name=$_POST['name'];
if(isset($_POST['update'])){
// if(isset($_POST['pro_hid'])){
    $sqlupdate="UPDATE project SET   project_name      ='".$_POST['name']."' ,
                                     project_gender    ='".$_POST['gender']."',
                                     project_email     = '".$_POST['email']."',
                                     project_message   ='".$_POST['message']."'  
                                     WHERE project_id  ='".@$_POST['project_id']."' ";


$runsql= mysqli_query($conn,$sqlupdate) or die(mysqli_errno($conn));
if($runsql){}
// echo 'data updated successfully';
$success=1;
}

?>




<?php
if($success){
    echo '<div class="alert alert-success alert-dismissible fade show text-center" role="alert">
  <strong>DATA!</strong> DATA UPDATED SUCCESSFULLY!!!!!.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
';
}

?>
<div class="container">
    <h2>Update Form</h2>
    <form action="#" method="POST"> 
        <div class="form-group">
            <label for="name">Company Name:</label>
            <input type="hidden" id="name" name="project_id" value="<?php echo $_GET['uid'] ?>" >
            <input type="text" id="name" name="name" value="<?php echo $editdata['project_name']  ?>">
           
        </div>
        <div class="form-group">
            <label>Gender:</label>
            <input type="radio" id="male" name="gender" value="male"
             <?php  if($editdata['project_gender']=='male') echo 'checked=checked'; ?>
            >
            
            <label for="male">Male</label>
            <input type="radio" id="female" name="gender" value="female" 
            <?php  if($editdata['project_gender']=='female') echo 'checked=checked'; ?>>
            <label for="female">Female</label>
            <input type="radio" id="other" name="gender" value="other" 
            <?php  if($editdata['project_gender']=='other') echo 'checked=checked'; ?>>
            <label for="other">Other</label>
          
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $editdata['project_email'] ?>">
           
        </div>
        <div class="form-group">
            <label for="message">Message:</label>
 <textarea id="message" name="message" rows="4"><?php echo $editdata['project_name']  ?></textarea>
         
        </div>
        <!-- <input type="submit" class="submit-btn" name="update" value="UPDATE"> -->
        <button type="submit" class="submit-btn" name="update">Submit</button>
    </form>
</div>


<?php  include 'footer.php'?>