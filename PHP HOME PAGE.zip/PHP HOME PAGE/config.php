<?php

$conn= mysqli_connect("localhost","root","","test") or die(mysqli_errno($conn));

if($conn){
    // echo 'connection done';
}else{
    echo 'connetion not done';
}

?>