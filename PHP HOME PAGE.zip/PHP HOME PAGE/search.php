<?php 
include 'header.php';
include 'config.php';
echo '<table class="table table-bordered">';
if(isset($_POST['searchbtn'])){
     $search=$_POST['search'];
     $sqlsearch="SELECT *FROM project where 
           project_id    LIKE '%$search%'
     or project_name     like '%$search%' 
     or project_gender   like '%$search%' 
     or project_email    like '%$search%' 
     or project_message  like '%$search%'";
     $runsearch= mysqli_query($conn,$sqlsearch)or die(mysqli_errno($conn));

    if(mysqli_num_rows($runsearch)>0){
     echo '<tr>
          <th>NAME</th>
          <th>GENDER</th>
          <th>EMAIL</th>
          <th>MESSAGE</th>
         </tr>';

         foreach($runsearch as $value){
         echo '<tr> 
         <td> '.$value["project_name"].' </td>
         <td> '.$value["project_gender"].' </td>
         <td> '.$value["project_email"].' </td>
         <td> '.$value["project_message"].' </td>
       
         </tr>'; }
    }
}else{
    echo '<tr>  <td colspan="6"> NO DATA FOUND  </td></tr>';
    }
echo '</table>';
?>