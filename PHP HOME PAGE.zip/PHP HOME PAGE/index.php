


<?php
 include 'header.php';
 include 'config.php';
 $success="0";
 $successVali=0;
 $name=$gender=$email=$gender=$message="";
 $nameErr=$genderErr=$emailErr=$messageErr="";
 if(isset($_POST['save'])){
  

    if(empty($_POST['name'])){
     $nameErr="Name is required";
    }else{
        $name=test_input($_POST['name']);
        
    }
    if (empty($_POST["gender"])) {
        $genderErr = "gender is required";
      } else {
        $gender = test_input($_POST["gender"]);
        
      }
    if (empty($_POST["email"])) {
        $emailErr = "email is required";
      } else {
        $email = test_input($_POST["email"]);
        
      }
    if (empty($_POST["message"])) {
        $messageErr = "message is required";
      } else {
        $message = test_input($_POST["message"]);
        
      }
    //   $name= $_POST['name'];
    //   echo $name;
       if(!empty($name)  &&  !empty($gender) && !empty($email) && !empty($message)){
       $sql ="INSERT INTO project (project_name,project_gender,project_email,project_message) VALUES ('".$_POST['name']."',
        '".$_POST['gender']."',  '".$_POST['email']."', '".$_POST['message']."')";
        // echo $sql;
        $runquery=mysqli_query($conn,$sql) or die(mysqli_errno($conn));
        if($runquery){
            // echo 'data  inserted successfully';
            $success="1";
            ?>  <meta HTTP-EQUIV="Refresh" content="3; URL=index.php">
            <?php  
        }
      }else{
        // echo "<h4 class='text-center bg-danger text-light'> ALL FIELD  REQUIRED </h4>";
         $successVali=1;
 }

}


      
function test_input($data){
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}


?>
</head>
<?php 
if($success){
    echo '<div class="alert alert-success alert-dismissible fade show text-center" role="alert">
  <strong>DATA!</strong> You message has been submitted!!!!!.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
';
}


?>
<body>
<a href="display.php" class="btn btn-primary float-sm-right m-2 p-2">SEE DATA</a>
<div class="container">
    <h2>Contact Form</h2>
    <?php if($successVali){
    echo '<div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
  <strong>All Fields!</strong> are Required!!!!!.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
';
} ?>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"  method="POST"> 
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="hidden" name="pro_id">
            <input type="text" id="name" name="name">
            <span class="error">* <?php echo $nameErr;?></span>
        </div>
        <div class="form-group">
            <label>Gender:</label>
            <input type="radio" id="male" name="gender" value="male">
            
            <label for="male">Male</label>
            <input type="radio" id="female" name="gender" value="female" >
            <label for="female">Female</label>
            <input type="radio" id="other" name="gender" value="other" >
            <label for="other">Other</label>
            <span class="error">* <?php  echo $genderErr ;?></span>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email">
            <span class="error">* <?php echo $emailErr;?></span>
        </div>
        <div class="form-group">
            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="4"></textarea>
            <span class="error">* <?php  echo $messageErr ;?></span>
        </div>
        <input type="submit" name="save" value="Submit">
    </form>
</div>

<?php include 'footer.php' ?>